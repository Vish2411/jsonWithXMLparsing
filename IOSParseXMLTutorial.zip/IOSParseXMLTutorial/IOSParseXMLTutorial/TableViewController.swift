//
//  TableViewController.swift
//  IOSParseXMLTutorial
//
//  Created by Arthur Knopper on 23/01/2019.
//  Copyright © 2019 Arthur Knopper. All rights reserved.
//

import UIKit
import SwiftyXMLParser
import Alamofire

struct Book {
    var bookTitle: String
    var bookAuthor: String
}

class TableViewController: UITableViewController{
    
    var books: [Book] = []
    var elementName: String = String()
    var bookTitle = String()
    var bookAuthor = String()

    override func viewDidLoad() {
        super.viewDidLoad()
        
        fetchData {
            self.tableView.reloadData()
        }
    }
    
    private func fetchData(compeleted: @escaping ()->()){
        
        let url = URL(string: "https://itunes.apple.com/us/rss/topgrossingapplications/limit=10/xml")
        
        URLSession.shared.dataTask(with: url!) { serverData, response, Error in
            if Error != nil{
                print(Error?.localizedDescription ?? "")
            }else{
                
                if let data = serverData{
                    do{
                        let newStr = String(data: data, encoding: String.Encoding.utf8)
                        print(newStr)
                                                
                        let parser = XMLParser(data: data)
                        parser.delegate = self
                        parser.parse()
                        
                        
                        
                        
                        //MARK: -  Fetch Data And crate Key For storing data as asual Storing json API Data
                        let request = AF.request("https://itunes.apple.com/us/rss/topgrossingapplications/limit=10/xml").responseData { response in
                            if let data = response.data {
                                let xml = XML.parse(data)
                                print(xml.feed.entry[0].title.text)
                                let feed = xml.feed
                                print(feed.id.text)
                            }
                        }
                        
                        DispatchQueue.main.async {
                            compeleted()
                        }
                        
                    }catch let error {
                        print(error.localizedDescription)
                        print("Fetching Error from API")
                    }
                }else{
                    print("Data is NOt Yet")
                }
                
                
            }
        }.resume()
    }
            
            
//MARK: - When Data Get Xml File
//        if let path = Bundle.main.url(forResource: "Books", withExtension: "xml") {
//            if let parser = XMLParser(contentsOf: path) {
//                parser.delegate = self
//
//                if parser.parse(){
//                    tableView.reloadData()
//                }
//            }
//        }
    
    //MARK: - Table view data source
    override func numberOfSections(in tableView: UITableView) -> Int {
        // return the number of sections
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // return the number of rows
        return books.count
    }

    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath)

        let book = books[indexPath.row]

        cell.textLabel?.text = book.bookTitle
        cell.detailTextLabel?.text = book.bookAuthor

        return cell
    }
}

//MARK: - XMl delegate Method
extension TableViewController : XMLParserDelegate {
    
    // 1
    func parser(_ parser: XMLParser, didStartElement elementName: String, namespaceURI: String?, qualifiedName qName: String?, attributes attributeDict: [String : String] = [:]) {
        
        if elementName == "book" {
            bookTitle = ""
            bookAuthor = ""
        }
        self.elementName = elementName
    }
    
    // 2
    func parser(_ parser: XMLParser, didEndElement elementName: String, namespaceURI: String?, qualifiedName qName: String?) {
        if elementName == "book" {
            let book = Book(bookTitle: bookTitle, bookAuthor: bookAuthor)
            books.append(book)
        }
    }
    
    // 3
    func parser(_ parser: XMLParser, foundCharacters string: String) {
        let data = string.trimmingCharacters(in: CharacterSet.whitespacesAndNewlines)
        
        if (!data.isEmpty) {
            if self.elementName == "title" {
                bookTitle += data
            } else if self.elementName == "author" {
                bookAuthor += data
            }
        }
    }
}
